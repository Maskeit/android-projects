package com.maskeit.libreria.Models;

public class DB {
    public static String NOMBRE_BD = "bd_libreria";

    public DB() {
    }
}
